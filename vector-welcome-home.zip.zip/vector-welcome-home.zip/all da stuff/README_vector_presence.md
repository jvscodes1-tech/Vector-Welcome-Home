# Vector presence-trigger monitor

This small script watches a target IP on your local network and triggers an action on an Anki Vector when the device appears (e.g. when your phone connects to Wi-Fi).

Files added
- `tools/vector_presence_monitor.py` — the watcher script.

Quick usage

```bash
python tools/vector_presence_monitor.py --target-ip 192.168.1.45 --simulate
```

To actually command Vector (drive off charger), run with `--allow-drive` and ensure the `anki_vector` SDK is installed and configured for your Vector:

```bash
python tools/vector_presence_monitor.py --target-ip 192.168.1.45 --allow-drive
```

You can also watch by MAC address (more reliable if your phone keeps a stable MAC for the SSID):

```bash
python tools/vector_presence_monitor.py --target-mac 28:9f:0f:e8:44:05 --simulate
```

Then when satisfied:

```bash
python tools/vector_presence_monitor.py --target-mac 28:9f:0f:e8:44:05 --allow-drive
```

Important safety notes
- By default the script only *simulates* actions. You must explicitly pass `--allow-drive` to enable movement.
- Test with `--simulate` first and confirm Vector behavior expectations before enabling drive.
- There's a `--cooldown` option to avoid repeated triggers; default is 60 seconds.

Requirements
- Python 3.7+
- Optional: `anki_vector` package if you want to control the robot directly.

If you want, I can adjust the script to use MAC address discovery, a UDP wake packet, or integrate with your router's device list instead of ping-based detection. Provide the phone IP or MAC and how you'd like it to detect presence.
