#!/usr/bin/env python3
"""
Vector Presence Monitor - Setup Installer
Prompts user for configuration and creates config.json
Also sets up Windows startup shortcut
"""

import json
import os
import sys
from pathlib import Path

CONFIG_FILE = os.path.join(os.path.dirname(__file__), "config.json")
STARTUP_FOLDER = Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"

def create_startup_shortcut():
    """Create a shortcut in Windows Startup folder"""
    try:
        import winshell
        script_dir = os.path.dirname(os.path.abspath(__file__))
        bat_path = os.path.join(script_dir, "run_monitor.bat")
        shortcut_path = os.path.join(STARTUP_FOLDER, "Vector_Monitor.lnk")
        
        link = winshell.shortcut(bat_path)
        link.write(shortcut_path)
        print(f"✓ Startup shortcut created at {shortcut_path}")
        return True
    except ImportError:
        # winshell not available, try alternative method
        try:
            import subprocess
            script_dir = os.path.dirname(os.path.abspath(__file__))
            bat_path = os.path.join(script_dir, "run_monitor.bat")
            shortcut_path = os.path.join(STARTUP_FOLDER, "Vector_Monitor.lnk")
            
            # Create VBScript to make shortcut
            vbs_script = f'''
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{shortcut_path}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "{bat_path}"
oLink.WorkingDirectory = "{os.path.dirname(bat_path)}"
oLink.Description = "Vector Presence Monitor"
oLink.Save
WScript.Echo "Shortcut created"
'''
            vbs_path = os.path.join(os.path.dirname(__file__), "create_shortcut.vbs")
            with open(vbs_path, "w") as f:
                f.write(vbs_script)
            subprocess.run(["cscript.exe", vbs_path], check=True)
            os.remove(vbs_path)
            print(f"✓ Startup shortcut created at {shortcut_path}")
            return True
        except Exception as e:
            print(f"⚠ Could not create startup shortcut: {e}")
            print(f"  You can manually create a shortcut to {os.path.dirname(__file__)}/run_monitor.bat")
            return False

def main():
    print("\n" + "="*60)
    print("Vector Presence Monitor - Setup Installer")
    print("="*60 + "\n")
    
    # Load existing config if available
    existing_config = {}
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            existing_config = json.load(f)
        print("Found existing configuration. You can leave fields blank to keep them.\n")
    
    # Prompt for settings
    print("Enter your configuration:\n")
    
    phone_ip = input(f"Phone IP address [{existing_config.get('phone_ip', '0.0.0.0')}]: ").strip()
    if not phone_ip:
        phone_ip = existing_config.get('phone_ip', '0.0.0.0')
    
    phone_mac = input(f"Phone MAC address [{existing_config.get('phone_mac', '00:00:00:00:00:00')}]: ").strip()
    if not phone_mac:
        phone_mac = existing_config.get('phone_mac', '00:00:00:00:00:00')
    
    bot_id = input(f"Vector Bot ID/Serial [{existing_config.get('bot_id', '00000000')}]: ").strip()
    if not bot_id:
        bot_id = existing_config.get('bot_id', '00000000')
    
    custom_message = input(f"Message to say on arrival [{existing_config.get('message', 'this is what vector says when you get home')}]: ").strip()
    if not custom_message:
        custom_message = existing_config.get('message', 'this is what vector says when you get home')
    
    # Save configuration
    config = {
        "phone_ip": phone_ip,
        "phone_mac": phone_mac,
        "bot_id": bot_id,
        "message": custom_message,
        "wirepod_ip": "localhost",
        "cooldown": existing_config.get('cooldown', 300),
        "wait_time": existing_config.get('wait_time', 5),  # 5 sec for testing
    }
    
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"\n✓ Configuration saved to {CONFIG_FILE}")
    print(f"\nSettings:")
    print(f"  Phone IP: {phone_ip}")
    print(f"  Phone MAC: {phone_mac}")
    print(f"  Vector Serial: {bot_id}")
    print(f"  Message: '{custom_message}'")
    
    # Set up startup
    print("\nSetting up Windows startup...")
    create_startup_shortcut()
    
    print("\n" + "="*60)
    print("✓ Setup complete! Vector monitor will now run on startup.")
    print("="*60 + "\n")
    input("Press Enter to close...")

if __name__ == "__main__":
    main()
