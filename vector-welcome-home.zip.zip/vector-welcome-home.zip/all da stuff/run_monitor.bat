@echo off
REM Vector Presence Monitor - Auto-start with settings from config.json

REM Check if config.json exists
if not exist config.json (
    echo error: set up install first
    pause
    exit /b 1
)

python vector_presence_monitor.py ^
  --skip-initial ^
  --allow-drive ^
  --action explore

pause
