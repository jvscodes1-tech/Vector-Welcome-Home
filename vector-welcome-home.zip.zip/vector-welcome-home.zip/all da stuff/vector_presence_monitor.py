"""Monitor a phone IP and trigger Anki Vector actions when it appears on the LAN (wirepod).

Usage:
  python tools/vector_presence_monitor.py --target-ip 192.168.1.159 --target-mac 28:9f:04:e8:44:05 --vector-ip 192.168.1.X --skip-initial --allow-drive

By default the script only simulates actions. To actually command Vector pass
`--allow-drive`. This prevents accidental driving during testing.
"""
import argparse
import platform
import subprocess
import time
import logging
import sys
import json
import os
import requests

try:
    import anki_vector
    from anki_vector.util import degrees
except Exception:
    anki_vector = None
import random


def is_host_up(ip, timeout_ms=1000):
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout_ms), ip]
    else:
        # On linux/mac use -c 1 and -W for timeout seconds
        timeout_s = str(max(1, int(timeout_ms / 1000)))
        cmd = ["ping", "-c", "1", "-W", timeout_s, ip]
    return subprocess.call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0


def is_mac_present(mac, ip=None):
    """Check local ARP table for the given MAC address.

    If ip is provided, ping it first to refresh the ARP table entry.
    Returns True if a matching MAC is found in the ARP table output.
    """
    # Refresh ARP by pinging the IP first
    if ip:
        try:
            subprocess.call(["ping", "-n", "1", "-w", "500", ip], 
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    
    try:
        out = subprocess.check_output(["arp", "-a"], stderr=subprocess.DEVNULL)
        text = out.decode(errors="ignore")
    except Exception:
        return False

    # normalize target: remove non-hex and lowercase
    target_norm = ''.join(c for c in mac.lower() if c in '0123456789abcdef')
    if len(target_norm) != 12:
        return False

    # find MAC-like tokens in arp output
    import re
    tokens = re.findall(r'([0-9a-fA-F]{2}(?:[:-][0-9a-fA-F]{2}){5})', text)
    for t in tokens:
        norm = ''.join(c for c in t.lower() if c in '0123456789abcdef')
        if norm == target_norm:
            return True

    # also check for dot-separated Cisco style (aaaa.bbbb.cccc)
    tokens2 = re.findall(r'([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})', text)
    for t in tokens2:
        norm = ''.join(c for c in t.lower() if c in '0123456789abcdef')
        if norm == target_norm:
            return True

    return False


def trigger_vector_action(vector_ip=None, allow_drive=False, simulate=False, serial="0dd1c98e", wait_sec=10, action="say", message="Yay, Joseph is home"):
    """Control Vector via wirepod REST API.

    action: 'say' (default) waits then says a message; 'explore' tries the intent
    endpoint `intent_explore_start` and falls back to wheel maneuvers if intent
    is unavailable.
    """
    logging.info("Triggering Vector action (action=%s vector_ip=%s serial=%s wait_sec=%d allow_drive=%s simulate=%s)", action, vector_ip, serial, wait_sec, allow_drive, simulate)

    if simulate or not allow_drive:
        if action == "say":
            logging.info("Simulating: Vector would wait %d seconds then say 'Yay, Joseph is home'", wait_sec)
        else:
            logging.info("Simulating: Vector would start exploring now")
        return True

    if not vector_ip:
        logging.error("Vector IP not provided. Use --vector-ip to specify the wirepod server IP address.")
        return False

    base_url = f"http://{vector_ip}:8080/api-sdk"

    try:
        # For explore action, call the intent endpoint only
        if action == "explore":
            try:
                logging.info("Requesting explore_start via wirepod cloud_intent endpoint (first call)...")
                resp = requests.post(f"{base_url}/cloud_intent?intent=explore_start&serial={serial}")
                logging.info("Intent response: %s", resp.status_code)
                if resp.status_code == 200:
                    logging.info("First explore intent sent successfully")
                    
                    # Wait before sending anything else
                    wait_between_intents = 3.0
                    logging.info("Waiting %.1f seconds before second intent...", wait_between_intents)
                    time.sleep(wait_between_intents)
                    
                    logging.info("Requesting explore_start via wirepod cloud_intent endpoint (second call)...")
                    resp2 = requests.post(f"{base_url}/cloud_intent?intent=explore_start&serial={serial}")
                    logging.info("Intent response (2nd): %s", resp2.status_code)
                    
                    # Wait before saying the message
                    wait_before_say = 5  # 5 seconds for testing (would be 60 for production)
                    logging.info("Waiting %d seconds before saying message...", wait_before_say)
                    time.sleep(wait_before_say)
                    
                    # Now say the message
                    logging.info("Assuming behavior control to say message...")
                    requests.post(f"{base_url}/assume_behavior_control?serial={serial}")
                    time.sleep(0.5)
                    
                    logging.info("Saying: %s", message)
                    requests.post(f"{base_url}/say_text?text={message}&serial={serial}")
                    time.sleep(2.0)
                    
                    logging.info("Releasing behavior control...")
                    requests.post(f"{base_url}/release_behavior_control?serial={serial}")
                    return True
                logging.warning("Intent endpoint did not return 200")
                return False
            except Exception:
                logging.exception("Error calling intent endpoint")
                return False

        # Default: say action
        logging.info("Assuming behavior control...")
        requests.post(f"{base_url}/assume_behavior_control?serial={serial}")
        time.sleep(0.5)

        # Wait for specified time
        logging.info("Waiting %d seconds...", wait_sec)
        time.sleep(wait_sec)

        # Say the message
        logging.info("Saying: %s", message)
        requests.post(f"{base_url}/say_text?text={message}&serial={serial}")
        time.sleep(2.0)

        # Release control
        logging.info("Releasing behavior control...")
        requests.post(f"{base_url}/release_behavior_control?serial={serial}")

        return True
    except Exception as e:
        logging.exception("Error while commanding Vector: %s", e)
        return False


def main():
    parser = argparse.ArgumentParser(description="Trigger Vector when a phone appears on the LAN (requires both IP and MAC) - wirepod edition")
    parser.add_argument("--target-ip", default=None, help="IP address of the phone to watch (default: from config.json)")
    parser.add_argument("--target-mac", default=None, help="MAC address of the phone to watch (default: from config.json)")
    parser.add_argument("--vector-ip", default=None, help="IP address of wirepod server (default: from config.json or localhost)")
    parser.add_argument("--serial", default=None, help="Vector serial ID (default: from config.json or 0dd1c98e)")
    parser.add_argument("--wait-time", type=int, default=None, help="Seconds to wait after getting off charger before saying message (default: from config.json or 10)")
    parser.add_argument("--interval", type=float, default=1.0, help="Seconds between checks (default: 1 for constant polling; use 300 for every 5 min)")
    parser.add_argument("--timeout-ms", type=int, default=1000, help="Ping timeout in ms (default: 1000)")
    parser.add_argument("--stable-check", type=int, default=2, help="Number of consecutive successful checks to consider 'up' (default:2)")
    parser.add_argument("--cooldown", type=int, default=None, help="Seconds to wait after triggering before re-triggering (default: from config.json or 300)")
    parser.add_argument("--simulate", action="store_true", help="Only simulate actions (no Vector commands)")
    parser.add_argument("--allow-drive", action="store_true", help="Allow the script to actually command Vector (required to drive)")
    parser.add_argument("--skip-initial", action="store_true", help="Skip triggering if phone is already on network at startup")
    parser.add_argument("--action", choices=["say", "explore"], default="say", help="Action to perform on arrival: 'say' or 'explore' (default: say)")
    parser.add_argument("--log-level", default="INFO")

    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, args.log_level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s: %(message)s")

    # Load configuration from config.json if it exists
    config_file = os.path.join(os.path.dirname(__file__), "config.json")
    config = {}
    if os.path.exists(config_file):
        try:
            with open(config_file) as f:
                config = json.load(f)
            logging.info("Loaded configuration from %s", config_file)
        except Exception as e:
            logging.warning("Failed to load config.json: %s", e)

    # Use config values as defaults, CLI args override
    target = args.target_ip or config.get("phone_ip", "0.0.0.0")
    target_mac = args.target_mac or config.get("phone_mac", "00:00:00:00:00:00")
    vector_ip = args.vector_ip or config.get("wirepod_ip", "localhost")
    serial = args.serial or config.get("bot_id", "00000000")
    wait_time = args.wait_time if args.wait_time is not None else config.get("wait_time", 10)
    interval = max(0.1, args.interval)
    stable_needed = max(1, args.stable_check)
    cooldown = max(0, args.cooldown if args.cooldown is not None else config.get("cooldown", 300))
    action = args.action
    custom_message = config.get("message", "Yay, Joseph is home")

    last_state_up = False
    last_trigger = 0

    logging.info("Watching BOTH ip=%s AND mac=%s every %.1fs (stable=%d) - simulate=%s allow_drive=%s wirepod_ip=%s serial=%s wait_time=%d cooldown=%d action=%s", target, target_mac, interval, stable_needed, args.simulate, args.allow_drive, vector_ip, serial, wait_time, cooldown, action)

    # Initialize last_state_up based on current presence (if --skip-initial, start as "already up")
    if args.skip_initial:
        # Try multiple times to refresh ARP/ping and require 'stable_needed' consecutive successes.
        max_initial_attempts = max(3, stable_needed * 2)
        consec = 0
        for attempt in range(max_initial_attempts):
            ip_ok = is_host_up(target, timeout_ms=args.timeout_ms)
            mac_ok = is_mac_present(target_mac, ip=target)
            if ip_ok and mac_ok:
                consec += 1
                if consec >= stable_needed:
                    last_state_up = True
                    last_trigger = time.time()  # avoid immediate retrigger
                    logging.info("Skipping initial trigger (device already present). Set last_trigger to now to honor cooldown.")
                    break
            else:
                consec = 0
            time.sleep(0.25)
        else:
            logging.info("Device not reliably present during startup; will trigger on next arrival.")

    try:
        while True:
            # check for consecutive successes to avoid transient flaps
            # BOTH IP and MAC must respond
            success_count = 0
            for _ in range(stable_needed):
                ip_ok = is_host_up(target, timeout_ms=args.timeout_ms)
                mac_ok = is_mac_present(target_mac, ip=target)  # refresh ARP by pinging
                both_ok = ip_ok and mac_ok

                if both_ok:
                    success_count += 1
                else:
                    break
                time.sleep(0.1)

            currently_up = (success_count >= stable_needed)

            if currently_up and not last_state_up:
                # new arrival (offline → online transition)
                now = time.time()
                if now - last_trigger < cooldown:
                    logging.info("Detected arrival but in cooldown (%.1fs remaining)", cooldown - (now - last_trigger))
                else:
                    logging.info("Detected device %s is now on the network. Triggering action.", target)
                    ok = trigger_vector_action(vector_ip=vector_ip, allow_drive=args.allow_drive, simulate=args.simulate, serial=serial, wait_sec=wait_time, action=action, message=custom_message)
                    if ok:
                        last_trigger = now

            last_state_up = currently_up
            time.sleep(interval)
    except KeyboardInterrupt:
        logging.info("Exiting on user interrupt")


if __name__ == "__main__":
    main()
